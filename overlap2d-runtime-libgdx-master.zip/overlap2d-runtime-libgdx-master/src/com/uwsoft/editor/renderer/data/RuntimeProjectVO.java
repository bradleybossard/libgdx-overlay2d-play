package com.uwsoft.editor.renderer.data;

import java.util.ArrayList;

public class RuntimeProjectVO {

	public ResolutionEntryVO originalResolution = new ResolutionEntryVO();
	public ArrayList<ResolutionEntryVO> resolutions = new ArrayList<ResolutionEntryVO>();
	
}
