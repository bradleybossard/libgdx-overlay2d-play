package com.uwsoft.editor.renderer.resources;

/**
 * Created by azakhary on 9/9/2014.
 */
public interface IResourceLoader extends  IDataLoader, IAssetLoader {


}
